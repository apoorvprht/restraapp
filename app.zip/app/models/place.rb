class Place < ActiveRecord::Base
	belongs_to :hotel
end
